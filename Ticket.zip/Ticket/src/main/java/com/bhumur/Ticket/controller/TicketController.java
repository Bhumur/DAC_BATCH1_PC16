package com.bhumur.Ticket.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bhumur.Ticket.dto.TicketDTO;
import com.bhumur.Ticket.entity.Ticket;
import com.bhumur.Ticket.service.TicketService;

@RestController
@RequestMapping("/Ticket")
public class TicketController{
	
	@Autowired
	TicketService ticketService;

	@PostMapping("/create")
	public void createTicket(@RequestBody Ticket ticket) {
		System.out.println("hello");
		ticketService.addTicket(ticket);
	}
	
	@GetMapping("/get/{id}")
	public TicketDTO getTicketById(@PathVariable("id")int id) {
		System.out.println("byebye");
		return ticketService.getTicketById(id);
	}
	
	
}
