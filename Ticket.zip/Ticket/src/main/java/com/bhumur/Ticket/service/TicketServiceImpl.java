package com.bhumur.Ticket.service;

import java.sql.Date;
import java.util.Iterator;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhumur.Ticket.dto.TicketDTO;
import com.bhumur.Ticket.entity.Ticket;
import com.bhumur.Ticket.entity.enums.Status;
import com.bhumur.Ticket.repo.TicketRepo;

@Service
public class TicketServiceImpl implements TicketService {
	@Autowired
	TicketRepo ticketRepo;

	@Override
	public TicketDTO addTicket(Ticket ticket) {
		Date date = new Date(System.currentTimeMillis());
		ticket.setCreatedate(date);
		Ticket t = ticketRepo.save(ticket);
		TicketDTO returnTicket = new TicketDTO();
		BeanUtils.copyProperties(returnTicket, t);
		return returnTicket;
	}

	@Override
	public TicketDTO updateTicket(Ticket ticket) {
		if(ticket.getStatus().equals(Status.valueOf("RESOLVED"))) {
			Date date = new Date(System.currentTimeMillis());
			ticket.setResolutiondate(date);
			Optional<Ticket> optional = ticketRepo.findById(ticket.getId());
			if(optional.isEmpty()) {
				System.out.println("not present");
				
			}
			else {
				Ticket x = optional.get();
				ticket.setStatus(null);
			}
		}
		
		
		Ticket t = ticketRepo.save(ticket);
		TicketDTO returnTicket = new TicketDTO();
		BeanUtils.copyProperties(returnTicket, t);
		return returnTicket;
	}

	@Override
	public Iterator<TicketDTO> allOpenTickets() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TicketDTO getTicketById(int ticketId) {
		Optional<Ticket> optional = ticketRepo.findById(ticketId);
		Ticket t = optional.get();
		TicketDTO returnTicket = new TicketDTO();
		BeanUtils.copyProperties(returnTicket, t);
		return returnTicket;
	}

}
