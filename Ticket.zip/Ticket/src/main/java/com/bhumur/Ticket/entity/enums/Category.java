package com.bhumur.Ticket.entity.enums;

public enum Category {
	SIM,
	CALLING,
	BROADBAND
}
