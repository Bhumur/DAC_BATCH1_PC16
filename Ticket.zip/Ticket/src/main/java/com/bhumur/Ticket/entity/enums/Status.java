package com.bhumur.Ticket.entity.enums;

public enum Status {
	OPEN,
	IN_PROGRESS,
	RESOLVED
}
